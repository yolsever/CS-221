#ifndef PNG_UTIL_H
#define PNG_UTIL_H

#include "cs221util/PNG.h"
using namespace cs221util;

PNG grayscale(PNG image);
PNG ubcify(PNG image);

#endif
